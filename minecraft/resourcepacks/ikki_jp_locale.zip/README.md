# IKKI 日本語化パック (ikki_jp_locale) v2

NeoForge 1.21.1 + 200+ MOD 環境向けの統合日本語化リソースパック。
整備パック (`ikki_fixpack`) とは独立した resourcepack として配布。

---

## 構成 (v2 時点)

| 区分 | MOD 数 | 件数 | ソース |
|---|---:|---:|---|
| **既存翻訳 取り込み (DIRECT)** | 24 | 10,521 keys | mine-tech 配布の 1.21.1 用 2026 年作成パック |
| **LLM 品質翻訳 (UI 厳密)** | 5 | 約 600 keys | chloride / accessories / xaeroworldmap / modonomicon UI / controlling |
| **DeepL Pro 品質翻訳 (用語集付き)** | 約 180 | 約 28,000 keys | DeepL Free API + IKKI MC 用語集 (651 entries) |
| **DeepL 補正不可残置** | — | 約 800 keys (英語) | placeholder 起因 HTTP 400 で恒久 skip |
| **合計** | **約 209** | **約 44,700 string keys** | **98.3% 日本語化** |

## 配置先

`<MC_INSTANCE>/resourcepacks/ikki_jp_locale.zip` として zip 化して配置。
ゲーム内 → オプション → リソースパック → **「IKKI 日本語化パック」を最上位** に。

`ikki_fixpack_assets` と併用する場合は、両方を有効化 (どちらが上でも干渉なし)。

---

## 翻訳品質ティア (v2)

### Tier 1: LLM 品質翻訳 (UI 厳密)
- **chloride** (162 keys) — Sodium スタイル設定 UI 全体を完訳
- **accessories** (137/178 keys) — 装備スロット名・トグル系を完訳
- **xaeroworldmap** (173 keys, v2 追加) — DeepL 失敗分を Claude で UI 文脈考慮で完訳
- **modonomicon UI** (78 keys, v2 追加) — ガイドブックの GUI/コマンド/ツールチップを完訳 (Demo book 91 keys は英語残置)
- **controlling** (12 keys, v2 追加) — キー設定ソート UI

### Tier 2: 既存翻訳 (mine-tech DIRECT) 取り込み
高品質な既存翻訳をそのまま採用 (24 MOD 分):
- occultism (3587) / ars_nouveau (2361) / ars_elemental (666) /
  distanthorizons (466) / hexalia (397) / sophisticatedbackpacks (363) /
  hearthandharvest (342) / not_enough_glyphs (237) / ars_additions (235) /
  ubesdelight (221) 他 14 件

### Tier 3: DeepL Free + 用語集 (v1 の Tier 3/4 を統合再翻訳)
DeepL Free API (月 100 万文字) + IKKI MC 用語集 (651 entries)
で約 180 MOD / 約 28,000 keys を再翻訳。

**用語集の代表例**:
- Sword=剣 / Pickaxe=ツルハシ / Diamond=ダイヤモンド / Netherite=ネザライト
- Health=体力 / Mana=マナ / Damage=ダメージ / Defense=防御
- Helmet=ヘルメット / Chestplate=チェストプレート / Leggings=レギンス / Boots=ブーツ
- Enchantment=エンチャント / Potion=ポーション / Recipe=レシピ
- Boss=ボス / Monster=モンスター / Familiar=使い魔
- 他 600 語超 (`glossary_en_ja.csv` 参照)

**v1 Tier 4 (辞書ベース機械翻訳) からの品質改善例**:
| キー | v1 (辞書) | v2 (DeepL+用語集) |
|---|---|---|
| Diamond Sword | ダイヤモンド 剣 | ダイヤモンド・ソード |
| Greatwhiteshark | 偉大 白 サメ | ホオジロザメ |
| Cooked Barracuda | 焼き バラクーダ | 焼いたバラクーダ |
| Mining Fortune | 鉱業 幸運 | フォーチュン |
| advancement title (JAWS) | (機械的直訳) | 「もっと大きなボートが必要だ……」 |

### Tier 4: 英語残置 (placeholder 起因 / 約 800 keys / 1.7%)
DeepL API が HTTP 400 を返す placeholder 含みテキスト (例: `§2%s§r` 連続) は
リトライ不能のため英語のまま残置。実際の UI 動作には影響しないが、
気になる場合は手動修正で対応可能。

---

## 既知の制限

- **v1 → v2 移行**: 辞書翻訳 (Tier 4) を完全に DeepL + 用語集ベースに置換 (品質ジャンプ)
- **MOD バージョン依存**: MOD アップデート時はキー追加分が英語に戻る可能性、追従再生成が必要
- **placeholder 残置**: 上記 Tier 4 (約 800 keys)

---

## 再翻訳の再現手順

```powershell
# DeepL API キーを環境変数にセット (Free プランで OK)
$env:DEEPL_API_KEY = "YOUR_KEY:fx"

# 1. 用語集を DeepL に登録 (.deepl_glossary_id.txt が生成される)
cd docs/ikki_jp_locale
python scripts/build_glossary.py --register

# 2. 全 Tier 4 MOD を翻訳 (DIRECT/LLM 保護)
python scripts/translate_with_deepl.py --all --exclude-file exclude_protected.txt

# 3. Claude overrides をマージ (xaeroworldmap / modonomicon UI)
python scripts/merge_overrides.py

# 4. 英語残置キーを 1-by-1 fallback でリトライ
python scripts/retry_untranslated.py
```

---

## 更新履歴

- **v2.6 (2026-08-06)**: エンチャント本の全数監査 + Apotheosis ガイドブックの章追従
  - **エンチャントは 188 個すべてを実データから突き合わせた**。名前の実体は lang キーではなく
    `data/<ns>/enchantment/*.json` の **`description` コンポーネント**なので、
    そこを起点に「表示名 / `.desc` / MOD 独自の `.description`」を照合している
    (`enchantment.<ns>.<name>` を決め打ちで引くと **Stellarity の 9 個を取りこぼす**)。
  - **名前 11 件を修正**: 語単位置換の残骸 5 件 (`Dune 速度` / `Mighty 風` / `虚空 Shot` /
    `虚空 Strike` / `呪文 Infinity`)、誤訳 2 件 (Soaring=高騰 → 飛翔 / Plated=メッキ加工 → 装甲板)、
    lang キーが無く英語 fallback が出ていた 4 件 (Stellarity の 破暁 / 竜の力 / 魂の収穫 +
    DungeonsArise の `lolth_curse`)。
  - 🔴 **DungeonsArise はキー名が MOD 側でずれている**。`lolths_curse.json` の
    `description` が引くのは **`enchantment.dungeons_arise.lolth_curse`** (s が無い)。
    `lolths_curse` の訳は前からあったのに**英語のまま出ていた**。別名キーを足して解決。
  - **説明 7 件を修正**: `iss_magicfromtheeast` 6 件 (「Increase effective の Spirit 呪文
    Power scaling オン spirit 矢.」のような語単位置換) と `azurelib` 1 件。
    合わせて用語も統一 (Spirit Spell Power=精霊呪文威力 / spirit arrow=精霊の矢)。
  - **説明 40 件を新規作成** (`enchdesc` が引く `.desc` が存在しなかったもの)。
    **MOD の内部データから効果を読んで書いている**: 1.21 のデータ駆動 `effects`
    (attributes / damage / post_attack の係数)、datapack の mcfunction
    (Stellarity の万華鏡・ドラゴンブレード・極寒の収穫者)、jar のクラス参照
    (tofucraft の Batch=`TofuDiamondToolUtil` / Drain=`TofuSwordItem` の耐久回復、
    benssharks の Serrated=`BleedingGlobalProcedure`、wispwillow=ランダム状態異常、
    ars_additions の Spellweave=`AlterationTable` のパーク枠拡張)。
    内訳: stellarity 22 / spell_power 8 / tofucraft 5 / その他 5。
  - ⚠ **`stellarity:void_locket/copper` (Power) は `effects` が空**。MOD 側で未実装なので
    説明にもそう明記した (訳し漏れではない)。
  - **Apotheosis ガイドブック `apoth_chronicle` の 14 ファイルを翻訳**。
    MOD が **Bosses → Apothic Invaders / Gems を独立章へ** と再編したため、
    既訳 (`bosses/` `affix_loot/gems`) が**旧パスに取り残されて章ごと英語表示**になっていた。
    新パス (`mobs/` `gems/` `world_tiers/`) へ、既訳の用語 (称号付きアイテム / ジェム /
    ソケット / レアリティ / ワールドレベル / 安全地帯・冒険・進撃・頂点・天界) を
    引き継いで作成。DynamicTrees ガイドの 2 ファイルも補完。
  - ✅ **psi / touhou_little_maid の本は未訳ではない**。この 2 冊は本文を lang キーで
    持つ方式で、`psi.book.*` 375 件 / `patchouli.touhou_little_maid.book.*` 146 件は
    既に翻訳済み。**ファイル数だけ数えると未訳に見える**ので注意。
  - 積み残し: `ars_nouveau:worn_notebook` (395) は整備計画 C16 で book 自体が
    コンパイル失敗のため引き続き保留。パック全体では語単位置換の壊れが
    **他カテゴリに約 1,300 キー**残っている (psi 178 / occultism 161 / ETF 122 ほか)。

- **v2.5 (2026-07-31)**: 全面監査で **カバレッジ 100%** 達成 + **pack_format を 34 へ修正**
  - 🔴 **`pack_format` が 48 (= datapack の値) になっていたのを 34 へ修正**。
    resourcepack と datapack は**番号体系が別**。48 のままだとクライアントが
    「非互換」判定し、`options.txt` の `incompatibleResourcePacks` に載っていた
    (`ikki_boss_client` も同じ間違いをしていたので同時に修正)。
    再発防止として `scripts/build_pack.py` にビルド前検証を追加し、
    リポジトリ全体を見る `IKKI_Manager/scripts/check_pack_formats.py` を新設。
  - **カバレッジ 99.4% → 100.0%** (73,470 キー)。日本語ファイルが無い MOD 11 → 0。
    翻訳 476 キーはローカル LLM が下訳し Claude が監修 (`local_llm.py`)。
  - **記法崩れ 32 件を修正** (致命 22 → 3 / 高 14 → 1)。残る致命 3 件は
    **EN 側のフォーマット文字列バグ**なので意図的に直していない。
  - **訳ゆれ 19 キーを統一** (例: 「Amphithere 矢」→「アンピプテラの矢」、
    「石造」→「石像」、鳩時計/カッコークロック → 鳩時計)。
  - ⚠ **検出器そのものが誤検出していた 6 種**を潰した過程は
    `IKKI_Manager/docs/handover_2026-07-31_locale.md` §2 に記録。
    記法崩れの件数は 196 → 141 → 86 → 51 と動いた。**数字を信じる前に実データを見る**。
  - 収録: **335 MOD / 55,479 キー** (パック側) + Patchouli ガイドブック 440 ファイル。

- **v2.4 (2026-06-07)**: 全 MOD 実スキャンによる翻訳漏れ一括補完 (99.7% 達成)
  - **監査ツール刷新** (`scripts/audit_coverage.py`): 「ja フラグ」ではなく
    クライアント全 445 jar の en_us.json / ja_jp.json を実際に突き合わせて
    カバレッジを算出。**MOD 同梱の ja_jp.json も「翻訳済み」として正しく計上**
    (例: 黄昏の森は jar 内蔵 2061 件で 98.9% 済 → 二重翻訳を回避)。
  - **ギャップ充填翻訳** (`scripts/topup_translate.py`): 未収録 + 英語残置の
    **3,981 キー / 約 10.9 万字**を DeepL Pro 品質 (用語集付き) で翻訳し、
    既存の良質訳・MOD 同梱訳を壊さずキー単位でマージ。完全未訳だった 25 MOD
    (`irons_apothic` / `valhelsia_furniture` / `apothic_spawners` 他) を新規翻訳、
    部分訳 85 MOD の漏れを補完。
  - **用語集を 678 entries に拡張**: 家具語 (Chair=椅子 / Table=テーブル /
    Drawer=引き出し 等) ・Aether 語 (Skyroot=スカイルート / Zanite=ザナイト /
    Holystone=ホーリーストーン) ・Apotheosis 語 (World Tier / Gateway / Affix) 等
    27 語を頻出語マイニングで追加 (`scripts/mine_glossary_candidates.py`)。
  - **Claude 品質補正**: DeepL が英語のまま返した 279 キーを精査し、実績説明・
    UI タグ・接辞名など自然文 6 キーを手動翻訳。残りは技術略語 (GUI/FPS/RGBA)・
    固有名詞 (Patreon/OptiFine)・config ID・数式 (sin/cos)・修飾キー (Ctrl/Alt) 等
    **慣例的に英語のまま使う語**として意図的に保持。
  - **品質検査**: placeholder (`%s`/`$()`) 整合性・`<ph>` タグ残り・HTML エンティティ
    混入をスキャンし全クリア (DeepL xml モードの `&gt;` 化を 1 件発見・修正)。
  - 全体カバレッジ **78,652 / 78,921 keys = 99.66%** (クライアント 312 namespace)。
  - パック生成 `scripts/build_pack.py` を追加 (zip 化 + クライアント配置)。

- **v2.3 (2026-05-29)**: boss_checklist UI + L2 Hostility ガイド翻訳漏れ補完
  - **boss_checklist** (490 keys) — ESC のボスチェックリスト UI / 設定画面
    (Progression mode / Search bar / Drop / Health 等) を Azure + Claude で翻訳。
    主要 UI 27 件は Claude で用語補正 (Settings=設定 / Search=検索 /
    「討伐者を記録」等)
  - **l2hostility / hostility_guide** (Patchouli book 38 ファイル / 110 文字列) —
    翻訳漏れを補完。`$(..)` 書式保護で Azure 翻訳
  - 汎用 Patchouli 翻訳スクリプト `translate_patchouli_book.py` を追加
    (en_us を jar から読み、name/text/title/description 等のみ翻訳 → ja_jp/ 展開)
  - **未翻訳だった Patchouli book を一括翻訳** (同スクリプト, Azure):
    croptopia/guide (172) / modulargolems/golem_guide (109) /
    twilightdelight/twilight_guide (13) / irons_spellbooks/iss_guide_book (10) /
    hexalia/verdant_grimoire (31) / dynamictrees/guide (17) /
    iceandfire/iceandfire (2) ※括弧内は ja ファイル数
  - **ars_nouveau/worn_notebook は翻訳保留**: 整備計画 C16 でこの book は
    コンパイル失敗 (空表示) のため、修正後に翻訳する

- **v2.2 (2026-05-28)**: winefoxs / Create / DH 強化 + Azure Translator 導入 (v0.14.0.14)
  - **winefoxs_spellbooks** (70 keys) — Iron's Spells メイドアドオン。Tier 4 訳が英単語残置だらけだったため Claude で完全再訳
  - **Create** (3,639 keys / 約 9 万文字) — 新規翻訳 (これまで ja_jp.json 不在)。**Azure Translator** で 98.9% 日本語化
  - **Distant Horizons** (v3.0.3) — 残置キーを補完し 99.6% 日本語化
  - **DeepL Free 月間枠 (50 万字) 到達** → 代替として **Azure Translator (F0, 月 200 万字)** を導入。`azure_translate.py` 追加 (batch ごと保存 + 429 リトライ対応)
  - 既知の制限: スクリーンショットに出る DH の "Useful Links" / "stop immediately" / "High vanilla render distance detected" 等は **MOD ソース内ハードコード** (lang 外) のため本パックでは日本語化不可

- **v2.1 (2026-05-28)**: 主要ドキュメント Tier 1 強化 (v0.14.0.13)
  - **PSI Encyclopaedia Psionica** (375 keys / 約 10 万文字) — Patchouli `$(...)` 書式保護を追加して再翻訳、品質大幅改善
  - **wispwillow Grimoire** (Patchouli book, 30 ファイル / 約 1.4 万文字) — Claude 完全翻訳
  - **l2backpack Backpack Guide** (Patchouli book, 18 ファイル / 約 3,800 文字) — Claude 完全翻訳
  - **touhou_little_mad** (覚えやすい幻想郷, lang book 25 keys) — Claude 完全翻訳
  - **touhou_little_maid_spell** (メイド呪文 MOD, 275 keys) — Claude 完全翻訳
  - 翻訳スクリプト拡張: `expand_patchouli_book.py` / `retranslate_psi_book.py` 追加

- **v2 (2026-05-28)**:
  - Tier 4 (辞書翻訳) を全廃、DeepL Free + IKKI MC 用語集 (651 entries) で再翻訳
  - 約 28,000 keys を品質再翻訳 (98.3% 日本語化達成)
  - xaeroworldmap / modonomicon UI / controlling を Claude で完訳
  - スクリプト 4 本 (build_glossary / translate_with_deepl / retry_untranslated / merge_overrides) を docs/ikki_jp_locale/scripts/ に同梱

- **v1 (2026-05-25)**: 初版
  - DIRECT 24 件取り込み (10,521 keys)
  - REFERENCE 19 件 merge (+5,555 keys)
  - 機械翻訳 163 件 (+23,238 keys)
  - LLM 翻訳 chloride + accessories
