Bliss v2.1.2 IKKI edit (Chocapic13' Shaders edit)

This is a modified version of "Bliss" (Xonk), which is based on "Chocapic13' Shaders" by Chocapic13.
All credit for the shaderpack goes to Chocapic13, Xonk and the contributors listed in CREDITS.txt.
The sharing rules in LICENSE.md (copied unchanged from the original pack) apply to this edit as well.
Redistribution of this edit: allowed under the same rules as LICENSE.md.

What was changed (only to run on macOS / Apple OpenGL 4.1, the look is meant to be identical):
- Apple's OpenGL has only 16 texture units, and Iris keeps 2 of them for itself in composite passes
  and always binds colortex0 = 13 left for the rest. With Distant Horizons the overworld "composite2"
  (shaders/dimensions/composite1.fsh) used 18 and "composite4" (shaders/dimensions/composite3.fsh) used 14.
- composite1 (shaders/dimensions/composite.fsh) now packs what composite2 reads at the current pixel
  (depthtex0, dhDepthTex, colortex1, colortex8, colortex15, colortex7.a, blue noise) into colortex10 and
  colortex15 (both RGBA32F, 3 bytes per channel as exact integers); composite2 reads those 2 instead
  (18 -> 13) and composite4 reads the depths from colortex10 (14 -> 13). Depths stay 32-bit floats;
  everything else was 8/16-bit already and is passed bit-exact.
- When RESOURCEPACK_SKY is not 0 (colortex10 is used for resource pack skies) the original code is used.
- shaders.properties: sky=false. gbuffers_skybasic only discards in every dimension (the sky is drawn in deferred),
  so the horizon, sky disc and sunrise fan draw calls produce nothing. The sun and moon are not affected.
- Every GLSL change is marked with "IKKI edit" in the source.

Entity shadows (2026-11-09, for frame rate; this one changes the look a little):
- lib/settings.glsl: the default of entityShadowDistanceMul is 0.15 instead of 0.25 (still selectable in the menu).
- New program shaders/world0/shadow_entities.vsh/.fsh (a copy of world0/shadow.vsh/.fsh plus a few lines):
  entity shadows fade out (blue-noise dithering) over the last 3 blocks before the entity shadow distance,
  so they no longer pop in and out. Blocks, block entities and the number of rendered entities are unchanged.

IKKI (Minecraft server) / 2026-11

2026-11-22 (dev): 盲目の時にネザー / エンドが真っ白に光る件を直した = lib/nether_fog.glsl・lib/end_fog.glsl の霞の色 (霧の色が黒の時に normalize が NaN) = 長さが 0 に近い時は黒 (research/bliss_fog/fix_blind_fog.py)
