# IKKI 日本語化パック - 取り込み元一覧

## DIRECT 採用 (24 件)

フィルタ条件: 作成バージョン = 1.21.1 + 日付 >= 2026-01-01 + 該当 MOD 導入済

- OK    [aethersdelight] 120 keys (aethersdelight-0.1.4.2-1.21.1_Japanese_Language_Pack_mine-tech_20260520.zip)
- OK    [ars_additions] 235 keys (ars_additions-1.21.1-21.3.0_Japanese_Language_Pack_mine-tech_20260523.zip)
- OK    [ars_controle] 83 keys (ars_controle-1.21.1-1.6.15_Japanese_Language_Pack_mine-tech_20260523.zip)
- OK    [ars_creo] 18 keys (ars_creo-1.21.1-5.3.1_Japanese_Language_Pack_mine-tech_20260523.zip)
- OK    [ars_elemancy] 195 keys (ars_elemancy-1.21.1-1.17_Japanese_Language_Pack_mine-tech_20260523.zip)
- OK    [ars_elemental] 666 keys (ars_elemental-1.21.1-0.7.9.3_Japanese_Language_Pack_mine-tech_20260523.zip)
- OK    [ars_nouveau] 2361 keys (ars_nouveau-1.21.1-5.11.5_Japanese_Language_Pack_mine-tech_20260523.zip)
- OK    [ars_technica] 169 keys (ars_technica-1.21.1-2.7.6_Japanese_Language_Pack_mine-tech_20260523.zip)
- OK    [crabbersdelight] 142 keys (crabbersdelight-1.21.1-1.2.6_Japanese_Language_Pack_mine-tech_20260522.zip)
- OK    [distanthorizons] 466 keys (DistantHorizons-2.4.5-b-1.21.1-fabric-neoforge_mine-tech_20260401.zip)
- OK    [ends_delight] 93 keys (ends_delight-2.5.1neoforge.1.21.1_Japanese_Language_Pack_mine-tech_20260521.zip)
- OK    [hearthandharvest] 342 keys (hearthandharvest-1.21.1-1.2.2_Japanese_Language_Pack_mine-tech_20260522.zip)
- OK    [hexalia] 397 keys (hexalia-1.3.1-1.21.1neoforge_Japanese_Language_Pack_mine-tech_20260503.zip)
- OK    [ice_and_fire_spellbooks] 25 keys (ice_and_fire_spellbooks-2.3.2-1.21.1_Japanese_Language_Pack_mine-tech_20260429.zip)
- OK    [modernui] 197 keys (ModernUI-NeoForge-1.21.1-3.12.0.2-universal_mine-tech_20260403.zip)
- OK    [not_enough_glyphs] 237 keys (not_enough_glyphs-1.21.1-4.4.0_Japanese_Language_Pack_mine-tech_20260523.zip)
- OK    [occultism] 3587 keys (occultism-1.21.1-neoforge-1.209.2_Japanese_Language_Pack_mine-tech_20260412.zip)
- OK    [particlerain] 144 keys (particlerain-4.0.0-beta.91.21.1-neoforge_mine-tech_20260402.zip)
- OK    [roadarchitect] 149 keys (roadarchitect-1.6.2-neoforge1.21.1_Japanese_Language_Pack_mine-tech_20260501.zip)
- OK    [roadarchitect_roadencounters] 91 keys (roadarchitect_encounters-1.1.0-neoforge1.21.1_Japanese_Language_Pack_mine-tech_20260502.zip)
- OK    [sophisticatedbackpacks] 363 keys (sophisticatedbackpacks-1.21.1-3.25.45.1742_Japanese_Language_Pack_mine-tech_20260515.zip)
- OK    [sound_physics_remastered] 72 keys (sound-physics-remastered-neoforge-1.21.1-1.5.1_Japanese_Language_Pack_mine-tech_20260410.zip)
- OK    [starbunclemania] 149 keys (starbunclemania-1.21.1-1.5.6_Japanese_Language_Pack_mine-tech_20260523.zip)
- OK    [ubesdelight] 221 keys (ubesdelight-neoforge-1.21.1-0.4.13_Japanese_Language_Pack_mine-tech_20260522.zip)

## 集計
- OK: 24
- WARN: 0
